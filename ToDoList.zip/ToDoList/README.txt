The first version of task manager.

To create new task press ENTER
To delete press DELETE